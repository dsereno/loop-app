export type InputSelectProperties = {
    id: number;
    label: string;
    hint: string;
    required: boolean;
}