export type InputBoolProperties = {
    id: number;
    label: string;
    hint: string;
    required: boolean;
}